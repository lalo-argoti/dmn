export interface User {
  id: number;
  name: string;
  email: string;
  // otros campos según tu tabla dmn_users
}
